import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::store
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:16
 * @route '/admin/zonas-envio'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/zonas-envio',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::store
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:16
 * @route '/admin/zonas-envio'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::store
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:16
 * @route '/admin/zonas-envio'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::store
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:16
 * @route '/admin/zonas-envio'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::store
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:16
 * @route '/admin/zonas-envio'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::update
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:36
 * @route '/admin/zonas-envio/{zona}'
 */
export const update = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/zonas-envio/{zona}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::update
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:36
 * @route '/admin/zonas-envio/{zona}'
 */
update.url = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { zona: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { zona: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    zona: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        zona: typeof args.zona === 'object'
                ? args.zona.id
                : args.zona,
                }

    return update.definition.url
            .replace('{zona}', parsedArgs.zona.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::update
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:36
 * @route '/admin/zonas-envio/{zona}'
 */
update.put = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::update
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:36
 * @route '/admin/zonas-envio/{zona}'
 */
    const updateForm = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::update
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:36
 * @route '/admin/zonas-envio/{zona}'
 */
        updateForm.put = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::destroy
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:56
 * @route '/admin/zonas-envio/{zona}'
 */
export const destroy = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/zonas-envio/{zona}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::destroy
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:56
 * @route '/admin/zonas-envio/{zona}'
 */
destroy.url = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { zona: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { zona: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    zona: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        zona: typeof args.zona === 'object'
                ? args.zona.id
                : args.zona,
                }

    return destroy.definition.url
            .replace('{zona}', parsedArgs.zona.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::destroy
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:56
 * @route '/admin/zonas-envio/{zona}'
 */
destroy.delete = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::destroy
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:56
 * @route '/admin/zonas-envio/{zona}'
 */
    const destroyForm = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminZonaEnvioController::destroy
 * @see app/Http/Controllers/Admin/AdminZonaEnvioController.php:56
 * @route '/admin/zonas-envio/{zona}'
 */
        destroyForm.delete = (args: { zona: number | { id: number } } | [zona: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const zonasEnvio = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default zonasEnvio