import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminSaborController::store
 * @see app/Http/Controllers/Admin/AdminSaborController.php:16
 * @route '/admin/sabores'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/sabores',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSaborController::store
 * @see app/Http/Controllers/Admin/AdminSaborController.php:16
 * @route '/admin/sabores'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSaborController::store
 * @see app/Http/Controllers/Admin/AdminSaborController.php:16
 * @route '/admin/sabores'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminSaborController::store
 * @see app/Http/Controllers/Admin/AdminSaborController.php:16
 * @route '/admin/sabores'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminSaborController::store
 * @see app/Http/Controllers/Admin/AdminSaborController.php:16
 * @route '/admin/sabores'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminSaborController::update
 * @see app/Http/Controllers/Admin/AdminSaborController.php:49
 * @route '/admin/sabores/{sabor}'
 */
export const update = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/sabores/{sabor}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminSaborController::update
 * @see app/Http/Controllers/Admin/AdminSaborController.php:49
 * @route '/admin/sabores/{sabor}'
 */
update.url = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sabor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sabor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sabor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sabor: typeof args.sabor === 'object'
                ? args.sabor.id
                : args.sabor,
                }

    return update.definition.url
            .replace('{sabor}', parsedArgs.sabor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSaborController::update
 * @see app/Http/Controllers/Admin/AdminSaborController.php:49
 * @route '/admin/sabores/{sabor}'
 */
update.post = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminSaborController::update
 * @see app/Http/Controllers/Admin/AdminSaborController.php:49
 * @route '/admin/sabores/{sabor}'
 */
    const updateForm = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminSaborController::update
 * @see app/Http/Controllers/Admin/AdminSaborController.php:49
 * @route '/admin/sabores/{sabor}'
 */
        updateForm.post = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminSaborController::destroy
 * @see app/Http/Controllers/Admin/AdminSaborController.php:90
 * @route '/admin/sabores/{sabor}'
 */
export const destroy = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/sabores/{sabor}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminSaborController::destroy
 * @see app/Http/Controllers/Admin/AdminSaborController.php:90
 * @route '/admin/sabores/{sabor}'
 */
destroy.url = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sabor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sabor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sabor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sabor: typeof args.sabor === 'object'
                ? args.sabor.id
                : args.sabor,
                }

    return destroy.definition.url
            .replace('{sabor}', parsedArgs.sabor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminSaborController::destroy
 * @see app/Http/Controllers/Admin/AdminSaborController.php:90
 * @route '/admin/sabores/{sabor}'
 */
destroy.delete = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminSaborController::destroy
 * @see app/Http/Controllers/Admin/AdminSaborController.php:90
 * @route '/admin/sabores/{sabor}'
 */
    const destroyForm = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminSaborController::destroy
 * @see app/Http/Controllers/Admin/AdminSaborController.php:90
 * @route '/admin/sabores/{sabor}'
 */
        destroyForm.delete = (args: { sabor: number | { id: number } } | [sabor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const sabores = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default sabores