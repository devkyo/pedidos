import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::estado
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:16
 * @route '/admin/pedidos/{pedido}/estado'
 */
export const estado = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: estado.url(args, options),
    method: 'patch',
})

estado.definition = {
    methods: ["patch"],
    url: '/admin/pedidos/{pedido}/estado',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::estado
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:16
 * @route '/admin/pedidos/{pedido}/estado'
 */
estado.url = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return estado.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::estado
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:16
 * @route '/admin/pedidos/{pedido}/estado'
 */
estado.patch = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: estado.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPedidoController::estado
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:16
 * @route '/admin/pedidos/{pedido}/estado'
 */
    const estadoForm = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: estado.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPedidoController::estado
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:16
 * @route '/admin/pedidos/{pedido}/estado'
 */
        estadoForm.patch = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: estado.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    estado.form = estadoForm
/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::destroy
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:32
 * @route '/admin/pedidos/{pedido}'
 */
export const destroy = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/pedidos/{pedido}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::destroy
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:32
 * @route '/admin/pedidos/{pedido}'
 */
destroy.url = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pedido: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pedido: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pedido: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pedido: typeof args.pedido === 'object'
                ? args.pedido.id
                : args.pedido,
                }

    return destroy.definition.url
            .replace('{pedido}', parsedArgs.pedido.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::destroy
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:32
 * @route '/admin/pedidos/{pedido}'
 */
destroy.delete = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPedidoController::destroy
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:32
 * @route '/admin/pedidos/{pedido}'
 */
    const destroyForm = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPedidoController::destroy
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:32
 * @route '/admin/pedidos/{pedido}'
 */
        destroyForm.delete = (args: { pedido: number | { id: number } } | [pedido: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::exportMethod
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:43
 * @route '/admin/pedidos/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/admin/pedidos/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::exportMethod
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:43
 * @route '/admin/pedidos/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::exportMethod
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:43
 * @route '/admin/pedidos/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminPedidoController::exportMethod
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:43
 * @route '/admin/pedidos/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPedidoController::exportMethod
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:43
 * @route '/admin/pedidos/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPedidoController::exportMethod
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:43
 * @route '/admin/pedidos/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminPedidoController::exportMethod
 * @see app/Http/Controllers/Admin/AdminPedidoController.php:43
 * @route '/admin/pedidos/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const pedidos = {
    estado: Object.assign(estado, estado),
destroy: Object.assign(destroy, destroy),
export: Object.assign(exportMethod, exportMethod),
}

export default pedidos