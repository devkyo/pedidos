import packs from './packs'
import sabores from './sabores'
import zonasEnvio from './zonas-envio'
import pedidos from './pedidos'
import settings from './settings'
const admin = {
    packs: Object.assign(packs, packs),
sabores: Object.assign(sabores, sabores),
zonasEnvio: Object.assign(zonasEnvio, zonasEnvio),
pedidos: Object.assign(pedidos, pedidos),
settings: Object.assign(settings, settings),
}

export default admin