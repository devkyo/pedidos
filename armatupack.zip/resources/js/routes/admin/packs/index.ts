import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminPackController::store
 * @see app/Http/Controllers/Admin/AdminPackController.php:15
 * @route '/admin/packs'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/packs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminPackController::store
 * @see app/Http/Controllers/Admin/AdminPackController.php:15
 * @route '/admin/packs'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPackController::store
 * @see app/Http/Controllers/Admin/AdminPackController.php:15
 * @route '/admin/packs'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPackController::store
 * @see app/Http/Controllers/Admin/AdminPackController.php:15
 * @route '/admin/packs'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPackController::store
 * @see app/Http/Controllers/Admin/AdminPackController.php:15
 * @route '/admin/packs'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\AdminPackController::update
 * @see app/Http/Controllers/Admin/AdminPackController.php:36
 * @route '/admin/packs/{pack}'
 */
export const update = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/packs/{pack}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\AdminPackController::update
 * @see app/Http/Controllers/Admin/AdminPackController.php:36
 * @route '/admin/packs/{pack}'
 */
update.url = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pack: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pack: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pack: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pack: typeof args.pack === 'object'
                ? args.pack.id
                : args.pack,
                }

    return update.definition.url
            .replace('{pack}', parsedArgs.pack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPackController::update
 * @see app/Http/Controllers/Admin/AdminPackController.php:36
 * @route '/admin/packs/{pack}'
 */
update.put = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPackController::update
 * @see app/Http/Controllers/Admin/AdminPackController.php:36
 * @route '/admin/packs/{pack}'
 */
    const updateForm = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPackController::update
 * @see app/Http/Controllers/Admin/AdminPackController.php:36
 * @route '/admin/packs/{pack}'
 */
        updateForm.put = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\AdminPackController::destroy
 * @see app/Http/Controllers/Admin/AdminPackController.php:57
 * @route '/admin/packs/{pack}'
 */
export const destroy = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/packs/{pack}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AdminPackController::destroy
 * @see app/Http/Controllers/Admin/AdminPackController.php:57
 * @route '/admin/packs/{pack}'
 */
destroy.url = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { pack: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { pack: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    pack: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        pack: typeof args.pack === 'object'
                ? args.pack.id
                : args.pack,
                }

    return destroy.definition.url
            .replace('{pack}', parsedArgs.pack.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminPackController::destroy
 * @see app/Http/Controllers/Admin/AdminPackController.php:57
 * @route '/admin/packs/{pack}'
 */
destroy.delete = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AdminPackController::destroy
 * @see app/Http/Controllers/Admin/AdminPackController.php:57
 * @route '/admin/packs/{pack}'
 */
    const destroyForm = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminPackController::destroy
 * @see app/Http/Controllers/Admin/AdminPackController.php:57
 * @route '/admin/packs/{pack}'
 */
        destroyForm.delete = (args: { pack: number | { id: number } } | [pack: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const packs = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default packs