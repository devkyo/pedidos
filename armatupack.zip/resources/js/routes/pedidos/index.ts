import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PedidoController::verificarDni
 * @see app/Http/Controllers/PedidoController.php:49
 * @route '/pedidos/verificar-dni/{dni}'
 */
export const verificarDni = (args: { dni: string | number } | [dni: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verificarDni.url(args, options),
    method: 'get',
})

verificarDni.definition = {
    methods: ["get","head"],
    url: '/pedidos/verificar-dni/{dni}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PedidoController::verificarDni
 * @see app/Http/Controllers/PedidoController.php:49
 * @route '/pedidos/verificar-dni/{dni}'
 */
verificarDni.url = (args: { dni: string | number } | [dni: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { dni: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    dni: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        dni: args.dni,
                }

    return verificarDni.definition.url
            .replace('{dni}', parsedArgs.dni.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::verificarDni
 * @see app/Http/Controllers/PedidoController.php:49
 * @route '/pedidos/verificar-dni/{dni}'
 */
verificarDni.get = (args: { dni: string | number } | [dni: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verificarDni.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PedidoController::verificarDni
 * @see app/Http/Controllers/PedidoController.php:49
 * @route '/pedidos/verificar-dni/{dni}'
 */
verificarDni.head = (args: { dni: string | number } | [dni: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verificarDni.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PedidoController::verificarDni
 * @see app/Http/Controllers/PedidoController.php:49
 * @route '/pedidos/verificar-dni/{dni}'
 */
    const verificarDniForm = (args: { dni: string | number } | [dni: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verificarDni.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PedidoController::verificarDni
 * @see app/Http/Controllers/PedidoController.php:49
 * @route '/pedidos/verificar-dni/{dni}'
 */
        verificarDniForm.get = (args: { dni: string | number } | [dni: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verificarDni.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PedidoController::verificarDni
 * @see app/Http/Controllers/PedidoController.php:49
 * @route '/pedidos/verificar-dni/{dni}'
 */
        verificarDniForm.head = (args: { dni: string | number } | [dni: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verificarDni.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verificarDni.form = verificarDniForm
/**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:77
 * @route '/pedidos'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/pedidos',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:77
 * @route '/pedidos'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:77
 * @route '/pedidos'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:77
 * @route '/pedidos'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PedidoController::store
 * @see app/Http/Controllers/PedidoController.php:77
 * @route '/pedidos'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const pedidos = {
    verificarDni: Object.assign(verificarDni, verificarDni),
store: Object.assign(store, store),
}

export default pedidos