import AdminDashboardController from './AdminDashboardController'
import AdminPackController from './AdminPackController'
import AdminSaborController from './AdminSaborController'
import AdminZonaEnvioController from './AdminZonaEnvioController'
import AdminPedidoController from './AdminPedidoController'
import AdminSettingController from './AdminSettingController'
const Admin = {
    AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
AdminPackController: Object.assign(AdminPackController, AdminPackController),
AdminSaborController: Object.assign(AdminSaborController, AdminSaborController),
AdminZonaEnvioController: Object.assign(AdminZonaEnvioController, AdminZonaEnvioController),
AdminPedidoController: Object.assign(AdminPedidoController, AdminPedidoController),
AdminSettingController: Object.assign(AdminSettingController, AdminSettingController),
}

export default Admin