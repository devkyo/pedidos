import PedidoController from './PedidoController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    PedidoController: Object.assign(PedidoController, PedidoController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers